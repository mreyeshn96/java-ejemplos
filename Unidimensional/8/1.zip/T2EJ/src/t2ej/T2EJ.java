/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {

    public void solicitar() {
      

    }

    public void calculos() {

    }

    public void imprimir() {
        
    }

    public void eliminarIndice(int array[], int index) {
        
    }
    
    public static void main(String[] args) {
        
        Scanner Sc = new Scanner(System.in);
        
        String[] Estudiantes = new String[10];

        for (int a = 0, b = Estudiantes.length; a < b; a++) {
            System.out.println("Ingrese el nombre del estudiante #" + (a + 1) + ":");
            Estudiantes[a] = Sc.nextLine();
        }
        
        for (int a = 0, b = Estudiantes.length; a < b; a++) {
            System.out.println( String.format("Estudiante #%d - Nombre: %s", a+1, Estudiantes[a]) );
        }
        
        System.out.println(" = = = Eliminar un estudiante = = = ");
        System.out.println(" Ingrese el número de estudiante que desea eliminar: ");
        
        int numEstudiante = Sc.nextInt();
        
        Estudiantes[numEstudiante-1] = "";
        
        for (int a = 0, b = Estudiantes.length; a < b; a++) {
            if( Estudiantes[a].length() == 0 )
                continue;
            System.out.println( String.format("Estudiante #%d - Nombre: %s", a+1, Estudiantes[a]) );
        }
        
        
        
        
        /*T2EJ Instancia = new T2EJ();

        // TODO code application logic here
        Instancia.solicitar();
        Instancia.calculos();
        Instancia.imprimir();*/
    }

}
