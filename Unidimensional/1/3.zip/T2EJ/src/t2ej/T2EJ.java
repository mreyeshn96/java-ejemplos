/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected int[] cursoA = new int[5];
    protected int[] cursoB = new int[5];
    protected float promedioCursoA;
    protected float promedioCursoB;
   
    public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        for(int a = 0, b = this.cursoA.length; a < b; a++) {
            System.out.println("Ingrese la nota del alumno #"+(a+1)+" del curso A:");
            this.cursoA[a] = Sc.nextInt();
        }
        
        for(int a = 0, b = this.cursoB.length; a < b; a++) {
            System.out.println("Ingrese la nota del alumno #"+(a+1)+" del curso B:");
            this.cursoB[a] = Sc.nextInt();
        }
    }
    
    public void calculos() {
        float sumaNotasCursoA = 0;
        float sumaNotasCursoB = 0;
        
        for(int a = 0, b = this.cursoA.length; a < b; a++) {
            sumaNotasCursoA += this.cursoA[a];
            sumaNotasCursoB += this.cursoB[a];
        }
        
        this.promedioCursoA = sumaNotasCursoA/cursoA.length;
        this.promedioCursoB = sumaNotasCursoB/cursoB.length;
    }
    
    public void imprimir() {
      System.out.print("= = = = RESULTADOS= = = =");
      String letraCurso = (this.promedioCursoA>this.promedioCursoB) ? "A" : "B";
      float promedioCurso = (this.promedioCursoA>this.promedioCursoB) ? this.promedioCursoA : this.promedioCursoB;
      System.out.println( String.format("\nEl mejor promedio es del curso %s con un promedio de %.2f.", letraCurso, promedioCurso) );
      System.out.print("\n");
    }
            
    public static void main(String[] args) {
        // TODO code application logic here
        T2EJ Instancia = new T2EJ();
        Instancia.solicitar();
        Instancia.calculos();
        Instancia.imprimir();
    }
    
}
