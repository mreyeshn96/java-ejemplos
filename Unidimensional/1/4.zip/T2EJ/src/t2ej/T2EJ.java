/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected int[] Vector = new int[10];
    protected Boolean estaOrdenado = true;
    
    public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        for(int a = 0, b = this.Vector.length; a < b; a++) {
            System.out.println("Ingrese el elemento #"+(a+1)+":");
            this.Vector[a] = Sc.nextInt();
        }
    }
    
    public void calculos() {
       for(int a = 0, b = this.Vector.length-1; a < b; a++) {
           if( this.Vector[a] > this.Vector[a+1] ) {
               this.estaOrdenado = false;
           }
       }
    }
    
    public void imprimir() {
        
        if( this.estaOrdenado ) {
            System.out.println("Los elementos del vector estan ordenados.");
        }
        else {
            System.out.println("Los elementos del vector no estan ordenados.");
        }
    }
            
    public static void main(String[] args) {
        // TODO code application logic here
        T2EJ Instancia = new T2EJ();
        Instancia.solicitar();
        Instancia.calculos();
        Instancia.imprimir();
    }
    
}
