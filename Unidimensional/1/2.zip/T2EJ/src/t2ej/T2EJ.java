/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected int[] primerVector = new int[4];
    protected int[] segundoVector = new int[4];
    protected int[] tercerVector = new int[4];
   
    public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        for(int a = 0, b = this.primerVector.length; a < b; a++) {
            System.out.println("Ingrese el elemento #"+(a+1)+" para el primer vector:");
            this.primerVector[a] = Sc.nextInt();
        }
        
        for(int a = 0, b = this.segundoVector.length; a < b; a++) {
            System.out.println("Ingrese el elemento #"+(a+1)+" para el primer vector:");
            this.segundoVector[a] = Sc.nextInt();
        }
    }
    
    public void calculos() {
        for(int a = 0, b = this.tercerVector.length; a < b; a++) {
            this.tercerVector[a] = this.primerVector[a] + this.segundoVector[a];
        }
    }
    
    public void imprimir() {
      System.out.print("= = = = VECTOR RESULTANTE = = = =");
      for(int a = 0, b = this.tercerVector.length; a < b; a++) {
          System.out.print( String.format("\ntercerVector[%d] = %d", a, this.tercerVector[a]) );
       }
      System.out.print("\n");
    }
            
    public static void main(String[] args) {
        // TODO code application logic here
        T2EJ Instancia = new T2EJ();
        Instancia.solicitar();
        Instancia.calculos();
        Instancia.imprimir();
    }
    
}
