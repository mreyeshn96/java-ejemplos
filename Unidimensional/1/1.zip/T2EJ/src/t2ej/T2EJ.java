/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected int[] elementos = new int[8];
    protected int totalElementos;
    protected int m50;
    protected int m36;
   
    public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        
        for(int a = 0, b = this.elementos.length; a < b; a++) {
            System.out.println( String.format("Ingresa el elemento #%d:", a+1) );
            this.elementos[a] = Sc.nextInt();
        }
    }
    
    public void calculos() {
        this.totalElementos = 0;
        this.m50 = 0;
        this.m36 = 0;
        for(int a = 0, b = this.elementos.length; a < b; a++) {
            this.totalElementos += this.elementos[a];
            if( this.elementos[a] > 36 ) {
                this.m36++;
            }
            if( this.elementos[a] > 50 ) {
                this.m50++;
            }
        }
    }
    
    public void imprimir() {
        System.out.println( String.format("El valor acumulado total es de %d", this.totalElementos) );
        System.out.println( String.format("El total de elementos mayores que 36 es de %d", this.m36) );
        System.out.println( String.format("El total de elementos mayores que 50 es de %d", this.m50) );
    }
            
    public static void main(String[] args) {
        // TODO code application logic here
        T2EJ Instancia = new T2EJ();
        Instancia.solicitar();
        Instancia.calculos();
        Instancia.imprimir();
    }
    
}
