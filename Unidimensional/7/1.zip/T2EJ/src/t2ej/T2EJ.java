/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
   protected int[] arregloA = new int[12];
   protected int[] arregloB = new int[12];
   protected int[] arregloC = new int[12];
   
     public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        
        for(int a = 0, b = this.arregloA.length; a < b; a++)
        {
            System.out.println("(Arreglo A) Ingrese un valor para la posicion #"+(a+1)+":");
            this.arregloA[a] = Sc.nextInt();
        }
      
        for(int a = 0, b = this.arregloB.length; a < b; a++)
        {
            System.out.println("(Arreglo B) Ingrese un valor para la posicion #"+(a+1)+":");
            this.arregloB[a] = Sc.nextInt();
        }
        
     
    }

    public void calculos() {
       this.arregloC[0] = this.arregloA[0];
       this.arregloC[1] = this.arregloA[1];
       this.arregloC[2] = this.arregloA[2];
       
       this.arregloC[3] = this.arregloB[0];
       this.arregloC[4] = this.arregloB[1];
       this.arregloC[5] = this.arregloB[2];
       
       this.arregloC[6] = this.arregloA[3];
       this.arregloC[7] = this.arregloA[4];
       this.arregloC[8] = this.arregloA[5];
       
       this.arregloC[9] = this.arregloB[3];
       this.arregloC[10] = this.arregloB[4];
       this.arregloC[11] = this.arregloB[5];
       
    }

    public void imprimir() {
        for(int a = 0, b = this.arregloC.length; a < b; a++)
        {
            System.out.println( String.format("(Arreglo C) Posicion #%d: %d", a, this.arregloC[a]) );
        }
    }

    public static void main(String[] args) {
        T2EJ Instancia = new T2EJ();
        
        // TODO code application logic here
        Instancia.solicitar();
        Instancia.calculos();
        Instancia.imprimir();
    }
    
}
