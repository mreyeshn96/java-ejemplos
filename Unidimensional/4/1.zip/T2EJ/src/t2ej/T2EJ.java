/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected float[] totalFactura = new float[5];
    protected String[] codigoProducto = new String[5];
    protected float[] precioProducto = new float[5];
    protected int[] cantidadProducto = new int[5];
    
    public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        
        for(int a = 0, b = 2; a < b; a++) {
            System.out.println( String.format("= = = = Factura #%04d = = = =", a+1) );
            System.out.println("Ingrese el código del producto:");
            this.codigoProducto[a] = Sc.next();
            
            System.out.println("Ingrese el precio unitario del producto:");
            this.precioProducto[a] = Sc.nextFloat();
            
            System.out.println("Ingrese el precio unitario del producto:");
            this.cantidadProducto[a] = Sc.nextInt();
            
            this.totalFactura[a] = this.precioProducto[a]*this.cantidadProducto[a];
        }
       
    }
    
    public void calculos() {
      
    }
    
    
    public void imprimir() {
        
        float totalFacturas = 0;
        for (int a = 0, b = 2; a < b; a++) {
            System.out.println( String.format("==> Detalle factura #%04d", a+1) );
            System.out.println( String.format("Còdigo de producto: %s\nPrecio unitario: %.2f\nCantidad: %d\nTotal de factura: %.2f", this.codigoProducto[a], this.precioProducto[a], this.cantidadProducto[a], this.totalFactura[a]) );
            
            totalFacturas += this.totalFactura[a];
        }
       
        System.out.println( String.format("Suma total de facturas: %.2f", totalFacturas) );
    }

    public static void main(String[] args) {
        T2EJ Instancia = new T2EJ();
        
        // TODO code application logic here
        Instancia.solicitar();
        Instancia.imprimir();
    }
    
}
