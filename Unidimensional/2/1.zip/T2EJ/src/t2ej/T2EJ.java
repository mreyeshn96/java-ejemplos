/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected String[] nombrePaises = new String[2];
    protected int[] habitantesPaises = new int[2];
    
    public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        
        for(int a = 0, b = this.nombrePaises.length; a < b; a++) {
            System.out.println( String.format("Ingresa el nombre del pais #%d:", a+1) );
            this.nombrePaises[a] = Sc.next();
            
            System.out.println( String.format("Ingresa la cantidad de habitantes de %s:", this.nombrePaises[a]) );
            this.habitantesPaises[a] = Sc.nextInt();
        }
       
    }
    
    public void calculos(String ordenTipo) {
      
        if( ordenTipo.equals("nombres") )
        {
            for (int a = 0, b = this.nombrePaises.length; a < b; a++) {
                System.out.println(""+this.habitantesPaises[a]);
                for (int c = 0, d = this.nombrePaises.length - 1 - a; c < d; d++) {
                    if (this.nombrePaises[c].compareTo(this.nombrePaises[c + 1]) > 0) {
                        String auxNombrePais = this.nombrePaises[c];
                        this.nombrePaises[c] = this.nombrePaises[c + 1];
                        this.nombrePaises[c + 1] = auxNombrePais;

                        int auxHabitantes = this.habitantesPaises[c];
                        this.habitantesPaises[c] = this.habitantesPaises[c + 1];
                        this.habitantesPaises[c + 1] = auxHabitantes;
                    }
                }
            }
        }
        else if( ordenTipo.equals("habitantes"))
        {
              for(int a = 0, b = this.habitantesPaises.length-1; a < b; a++) {
                for(int c = 0, d = this.habitantesPaises.length-1-a; c < d; d++) {
                    if( this.habitantesPaises[c+1] < this.habitantesPaises[c] ) {
                        int auxHabitantes = this.habitantesPaises[c];
                        this.habitantesPaises[c] = this.habitantesPaises[c+1];
                        this.habitantesPaises[c+1] = auxHabitantes;
                        
                        String auxNombrePais = this.nombrePaises[c];
                        this.nombrePaises[c] = this.nombrePaises[c+1];
                        this.nombrePaises[c+1] = auxNombrePais;
                       
                    }
                }
            }
        }
        else {
            System.out.println("Algo ha fallado.");
        }
    }
    
    
    public void imprimir() {
        
        this.calculos("nombres");
        for (int a = 0, b = this.habitantesPaises.length; a < b; a++) {
            System.out.println(String.format("%s con %d habitantes.", this.nombrePaises[a], this.habitantesPaises[a]));
        }

        this.calculos("habitantes");
        for (int a = 0, b = this.habitantesPaises.length; a < b; a++) {
            System.out.println(String.format("%s con %d habitantes.", this.nombrePaises[a], this.habitantesPaises[a]));
        }
    }

    public static void main(String[] args) {
        T2EJ Instancia = new T2EJ();
        
        // TODO code application logic here
        Instancia.solicitar();
        Instancia.imprimir();
    }
    
}
