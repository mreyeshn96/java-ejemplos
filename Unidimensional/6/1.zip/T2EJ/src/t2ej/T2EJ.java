/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
   protected int[] numero = new int[6];
   protected int numMayor;
   protected int numMenor;
   
     public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        
        for(int a = 0, b = this.numero.length; a < b; a++) {
            System.out.println("Ingresa un numero para la posicion #"+(a+1)+":");
            this.numero[a] = Sc.nextInt();
        }
    }

    public void calculos() {
        for(int a = 0, b = this.numero.length; a < b; a++) {
            if( this.numero[a] > this.numMayor )
            {
                this.numMayor = this.numero[a];
            }
            if( this.numero[a] < this.numMenor || a == 0)
            {
                this.numMenor = this.numero[a];
            }
        }
    }

    public void imprimir() {
        System.out.println("Numero mayor: "+this.numMayor+"\nNumero menor: "+this.numMenor);
    }

    public static void main(String[] args) {
        T2EJ Instancia = new T2EJ();
        
        // TODO code application logic here
        Instancia.solicitar();
        Instancia.calculos();
        Instancia.imprimir();
    }
    
}
