/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected int[] edades = new int[10];
    
    public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        
        for(int a = 0, b = this.edades.length; a < b; a++) {
            System.out.println( String.format("Ingresa la edad de la persona #%d:", a+1) );
            this.edades[a] = Sc.nextInt();
        }
       
    }
    
    public void calculos() {
      
    }
    
    
    public void imprimir() {
        for (int a = 9; a > -1; a--) {
            System.out.println(this.edades[a]);
        }
       
    }

    public static void main(String[] args) {
        T2EJ Instancia = new T2EJ();
        
        // TODO code application logic here
        Instancia.solicitar();
        Instancia.imprimir();
    }
    
}
