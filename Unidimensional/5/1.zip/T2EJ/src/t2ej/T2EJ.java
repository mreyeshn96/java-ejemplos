/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected float[] ventas = new float[30];
    protected int sup;
    protected int inf; 
    
    public void solicitar() {
        Scanner Sc = new Scanner(System.in);
        
        for(int a = 0, b = this.ventas.length; a < b; a++) {
            System.out.println( String.format("= = = = Ingrese el valor de la venta #%d= = = =", a+1) );
            this.ventas[a] = Sc.nextFloat();
            
        }
       
    }
    
    public void calculos() {
        for(int a = 0, b = this.ventas.length; a < b; a++) {
            if( this.ventas[a] > 10500 ) {
                this.sup++;
            }
            else
            {
                this.inf++;
            }
        }
    }
    
    
    public void imprimir() {
        
        System.out.println("Un total de "+this.sup+" ventas fueron superiores a L.10,500.");
        System.out.println("Un total de "+this.inf+" ventas fueron inferiores a L.10,500.");
    }

    public static void main(String[] args) {
        T2EJ Instancia = new T2EJ();
        
        // TODO code application logic here
        Instancia.solicitar();
        Instancia.calculos();
        Instancia.imprimir();
    }
    
}
