/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected int[][] matriz;
    protected int filas;
    protected int columnas;
    protected int mayorFila;
    protected int mayorColumna;
    protected int mayor;

    public void solicitar() {
       Scanner Sc = new Scanner(System.in);
       
       System.out.println("Ingrese el numero de filas que tendra el arreglo:");
       this.filas = Sc.nextInt();
       
       System.out.println("Ingrese el numero de columnas que tendra el arreglo:");
       this.columnas = Sc.nextInt();
       
       this.matriz = new int[this.filas][this.columnas];
       
       for(int a = 0, b = this.matriz.length; a < b; a++) {
           for(int c = 0, d = this.matriz[a].length; c < d; c++) {
               System.out.println( String.format("Ingrese un numero entero para la posicion [%d, %d]", a, c) );
               this.matriz[a][c] = Sc.nextInt();
           }
       }
       
    }

    public void calculos() {
        this.mayor = this.matriz[0][0];
         for(int a = 0, b = this.matriz.length; a < b; a++) {
           for(int c = 0, d = this.matriz[a].length; c < d; c++) {
              if( this.matriz[a][c] > this.mayor ) {
                  this.mayorColumna = c;
                  this.mayorFila = a;
                  this.mayor = this.matriz[a][c];
              }
           }
       }
    }

    public void imprimir() {
        System.out.println( String.format("El numero mas alto ingresado es: %d", this.mayor) );
        System.out.println( String.format("Esta almacenado en la posicion: %d, %d", this.mayorFila, this.mayorColumna) );
    }

    public static void main(String[] args) {
       
        
        T2EJ Instancia = new T2EJ();

        // TODO code application logic here
        Instancia.solicitar();
        Instancia.calculos();
        Instancia.imprimir();
    }

}
