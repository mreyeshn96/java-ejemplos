/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected int[][] matriz;
    protected int filas;
    protected int columnas;

    public void solicitar() {
       Scanner Sc = new Scanner(System.in);
       
       System.out.println("Ingrese el numero de filas que tendra el arreglo:");
       this.filas = Sc.nextInt();
       
       System.out.println("Ingrese el numero de columnas que tendra el arreglo:");
       this.columnas = Sc.nextInt();
       
       this.matriz = new int[this.filas][this.columnas];
       
       for(int a = 0, b = this.matriz.length; a < b; a++) {
           for(int c = 0, d = this.matriz[a].length; c < d; c++) {
               System.out.println( String.format("Ingrese un numero entero para la posicion [%d, %d]", a, c) );
               this.matriz[a][c] = Sc.nextInt();
           }
       }
       
    }

    public void calculos() {

    }

    public void imprimir() {
        System.out.println(" = = = = MATRIZ COMPLETA = = = =");
        for(int a = 0, b = this.matriz.length; a < b; a++) {
           for(int c = 0, d = this.matriz[a].length; c < d; c++) {
               System.out.println( String.format("Matriz [%d, %d]: %d", a, c, this.matriz[a][c]) );
           }
       }
        
        System.out.println(" = = = = ULTIMA FILA = = = =");
        for(int a = 0, b = this.matriz[0].length; a < b; a++) {
           System.out.println( String.format("Matriz [%d, %d]: %d", this.matriz.length-1, a, this.matriz[this.matriz.length-1][a]) );
       }
    }

    public static void main(String[] args) {
       
        
        T2EJ Instancia = new T2EJ();

        // TODO code application logic here
        Instancia.solicitar();
        //Instancia.calculos();
        Instancia.imprimir();
    }

}
