/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected int[][] matriz = new int[3][4];

    public void solicitar() {
       Scanner Sc = new Scanner(System.in);
       
       for(int a = 0, b = this.matriz.length; a < b; a++) {
           for(int c = 0, d = this.matriz[a].length; c < d; c++) {
               System.out.println( String.format("Ingrese un numero entero para la posicion [%d, %d]:", a, c) );
               this.matriz[a][c] = Sc.nextInt();
           }
       }
    }

    public void calculos() {

    }
  
    public void imprimirPrimeraFila() {
        System.out.println(" = = = = Primera fila = = = = ");
        for (int a = 0, b = this.matriz[0].length; a < b; a++) {
            System.out.println(String.format("Primera fila [0, %d]: %d", a, this.matriz[0][a]));
        }
    }

    public void imprimirUltimaFila() {
        System.out.println(" = = = = Ultima fila = = = = ");
        for (int a = 0, b = this.matriz[0].length; a < b; a++) {
            System.out.println(String.format("Ultima fila [%d, 0]: %d", a, this.matriz[this.matriz.length-1][a]));
        }
    }
    
     public void imprimirPrimeraColumna() {
        System.out.println(" = = = = Primera columna = = = = ");
        for (int a = 0, b = this.matriz.length; a < b; a++) {
            System.out.println(String.format("Ultima fila [%d, 0]: %d", a, this.matriz[a][0]));
        }
    }

    public void imprimir() {
       this.imprimirPrimeraFila();
       this.imprimirUltimaFila();
       this.imprimirPrimeraColumna();
    }

    public static void main(String[] args) {
       
        
        T2EJ Instancia = new T2EJ();

        // TODO code application logic here
        Instancia.solicitar();
        //Instancia.calculos();
        Instancia.imprimir();
    }

}
