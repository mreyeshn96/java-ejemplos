/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2ej;

import java.util.Scanner;

/**
 *
 * @author doris
 */
public class T2EJ {
    
    protected int[][] matriz = new int[3][5];

    public void solicitar() {
       Scanner Sc = new Scanner(System.in);
       
       for(int a = 0, b = this.matriz.length; a < b; a++) {
           for(int c = 0, d = this.matriz[a].length; c < d; c++) {
               System.out.println( String.format("Ingrese un numero entero para la posicion [%d, %d]:", a, c) );
               this.matriz[a][c] = Sc.nextInt();
           }
       }
    }

    public void calculos() {

    }

    public void imprimir() {
        for(int a = 0, b = this.matriz.length; a < b; a++) {
           for(int c = 0, d = this.matriz[a].length; c < d; c++) {
               System.out.println( String.format("Matriz [%d, %d]: %d", a, c, this.matriz[a][c]) );
           }
       }
    }

    public void eliminarIndice(int array[], int index) {
        
    }
    
    public static void main(String[] args) {
       
        
        T2EJ Instancia = new T2EJ();

        // TODO code application logic here
        Instancia.solicitar();
        //Instancia.calculos();
        Instancia.imprimir();
    }

}
